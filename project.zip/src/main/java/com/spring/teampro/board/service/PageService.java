package com.spring.teampro.board.service;

public class PageService {

}
