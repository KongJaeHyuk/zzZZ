package com.spring.teampro.board.dao;

import java.util.List;
import java.util.Map;

import com.spring.teampro.board.dto.PageDTO;

public class PageDAO {

}
