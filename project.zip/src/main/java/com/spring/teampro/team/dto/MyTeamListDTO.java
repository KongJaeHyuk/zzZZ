package com.spring.teampro.team.dto;

public class MyTeamListDTO {

		private int t_key;
		private String t_name;
		private int userkey;
		private int t_field;
		private String t_field2;
		private String tm_joinDate;
		private int t_number;
		
		public int getT_key() {
			return t_key;
		}
		public void setT_key(int t_key) {
			this.t_key = t_key;
		}
		public String getT_name() {
			return t_name;
		}
		public void setT_name(String t_name) {
			this.t_name = t_name;
		}
		public int getUserkey() {
			return userkey;
		}
		public void setUserkey(int userkey) {
			this.userkey = userkey;
		}
		public int getT_field() {
			return t_field;
		}
		public void setT_field(int t_field) {
			this.t_field = t_field;
		}
		public String getTm_joinDate() {
			return tm_joinDate;
		}
		public void setTm_joinDate(String tm_joinDate) {
			this.tm_joinDate = tm_joinDate;
		}
		public String getT_field2() {
			return t_field2;
		}
		public void setT_field2(String t_field2) {
			this.t_field2 = t_field2;
		}
		public int getT_number() {
			return t_number;
		}
		public void setT_number(int t_number) {
			this.t_number = t_number;
		}
		
		
}
